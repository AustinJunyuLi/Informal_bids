function y = value_function(x)
    y = norm(x)+abs(x(1))/sin(x(2));