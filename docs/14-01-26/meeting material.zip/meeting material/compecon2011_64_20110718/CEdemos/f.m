% F Example function
function y=f(x)
y = x^0.5;